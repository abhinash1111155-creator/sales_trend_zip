
# Sales Trend Analysis Using Aggregations — Internship Task 6

## 📌 Objective
Analyze monthly revenue and order volume using SQL aggregation functions.

## 🛠 Tools Used
- PostgreSQL / MySQL / SQLite

## 📂 Deliverables Included in This ZIP
- **sales_trend_analysis.sql** — SQL script for trend analysis  
- **sales_trend_analysis.pdf** — PDF report  
- **results_table.csv** — Sample output format  
- **README.md** — Documentation  

## 📊 SQL Logic Used
- `SUM()` for total revenue  
- `COUNT(DISTINCT order_id)` for total orders  
- `EXTRACT(YEAR/MONTH)` for date aggregation  
- `GROUP BY` and `ORDER BY` for chronological trend  

## 📝 How to Run
1. Import the script into your SQL environment.
2. Ensure your table name is **online_sales** with fields:
   - order_date  
   - amount  
   - order_id  
   - product_id  
3. Execute and analyze the results.

## 📤 GitHub Instructions
- Upload all files into a new repository.
- Add screenshots, code, dataset (if allowed), and results.
- Include this README.
